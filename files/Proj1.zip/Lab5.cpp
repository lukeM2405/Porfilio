#include <iostream>
#include <limits>
#include <fstream>
#include <string>
#include <cctype>
#include <set>
#include <map>
#include <sstream>
#include "imdb.h"

using namespace std;

void analyzeCoActors(const IMDB& imdb);
void analyzeMovies(const IMDB& imdb);

int main(int argc, char* argv[])
{
    const int COMM_NUM = 1;
    cout << "Welcome to CS216 IMDB Finder!" << endl;

    // Check whether the number of command line arguments is exactly one
    if (argc != COMM_NUM + 1)
    {
        cout << "Warning: need exactly " << COMM_NUM << " command line argument." << endl;
        cout << "Usage: " << argv[0] << " inputfile_name" << endl;
        return 1;
    }

    ifstream in_file;
    in_file.open(argv[COMM_NUM]);

    // Check whether the input file can be opened successfully or not
    if (!in_file.good())
    {
        cout << "Warning: cannot open file named " << argv[COMM_NUM] << "!" << endl;
        return 2;
    }

    // Read data from the input file
    IMDB cs216_imdb;

    while (!in_file.eof())
    {
        string line;
        getline(in_file, line);
        string actorName, movieTitle;

        // Tokenize the line
        if (line.length() != 0)
        {
            istringstream iss(line);
            getline(iss, actorName,';');
            iss >> ws; // Extract extra white space

            set<string> movies;
            while (getline(iss, movieTitle, ';'))
            {
                movies.insert(movieTitle);
                iss >> ws;
            }

            // Insert the pair to IMDB object
            cs216_imdb.insert_an_actor(actorName, movies);
        }
    }
    // Close the input file
    in_file.close();

    int option;
    while (true)
    {
        cout << "This application stores information about Actors and their Movies, please choose your option (Enter Q or q to quit):" << endl;
        cout << "1. Actors in Movies" << endl;
        cout << "2. Actors and co-actors" << endl;

        cin >> option;
        if (cin.fail())
        {
            cin.clear();
            string input_to_check;
            cin >> input_to_check;
            if (input_to_check == "Q" || input_to_check == "q")
            {
                break;
            }
            else
            {
                cout << "Expecting a number as the option!" << endl;
                continue;
            }
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        // Handle valid option inputs
        switch (option)
        {
            case 1:
                analyzeMovies(cs216_imdb);  // Option 1: Movie matching and further operations
                break;
            case 2:
                analyzeCoActors(cs216_imdb);  // Option 2: Co-actors of an actor
                break;
            default:
                cout << "Invalid option number!" << endl;
        }
    }
    cout << "Thank you for using my program, bye..." << endl;
    return 0;
}

/*
 * Purpose: this function allows the user to input two movie titles, 
 * and performs the operations A, C, O (union, intersection, and difference)
 * @param imdb: IMDB object storing actor and movie dat
 */
void analyzeMovies(const IMDB& imdb) {
    string movie1;
	   string movie2;

    cout << "Please input the first movie title: ";
    getline(cin, movie1);

    cout << "Please input the second movie title: ";
    getline(cin, movie2);

    // Perform match
    string matchedMovie1 = imdb.matchExistingMovie(movie1);
    string matchedMovie2 = imdb.matchExistingMovie(movie2);

    if (matchedMovie1.empty() || matchedMovie2.empty()) {
        if (matchedMovie1.empty()) {
            cout << "\"" << movie1 << "\" is not a VALID movie title!" << endl;
        }
        if (matchedMovie2.empty()) {
            cout << "\"" << movie2 << "\" is not a VALID movie title!" << endl;
        }
        return;
    }

    cout << "Your input matches the following two movies: " << endl;
    cout << matchedMovie1 << endl;
    cout << matchedMovie2 << endl;

    cout << "Both movies are in the database, please continue..." << endl;
    cout << "This is written by Lucas Morris, and I hope you enjoy it." << endl;

    string subOption;
    while (true)
    {
        cout << "Please input your menu option (enter Q or q to quit):" << endl;
        cout << "A -- to print all the actors in either of the two movies." << endl;
        cout << "C -- to print all the common actors in both movies." << endl;
        cout << "O -- to print all the actors who are in only one movie, but not in both." << endl;
        cout << "> ";  // Prompt

        // Read input
        cin >> subOption;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Clear buffer

        if (subOption == "A" || subOption == "a") {
            // Union of actors in both movies
            set<string> actorsInMovie1 = imdb.find_actors_in_a_movie(matchedMovie1);
            set<string> actorsInMovie2 = imdb.find_actors_in_a_movie(matchedMovie2);

            set<string> unionSet = actorsInMovie1;
            unionSet.insert(actorsInMovie2.begin(), actorsInMovie2.end());

            cout << "All the actors in either of the two movies:" << endl;
            for (const auto& actor : unionSet) {
                cout << actor << endl;
            }

        } else if (subOption == "C" || subOption == "c") {
            // Intersection of actors in both movies
            set<string> actorsInMovie1 = imdb.find_actors_in_a_movie(matchedMovie1);
            set<string> actorsInMovie2 = imdb.find_actors_in_a_movie(matchedMovie2);

            cout << "Common actors in both movies:" << endl;
            for (const auto& actor : actorsInMovie1) {
                if (actorsInMovie2.count(actor)) {
                    cout << actor << endl;
                }
            }

        } else if (subOption == "O" || subOption == "o") {
            // Symmetric difference: actors in one but not both movies
            set<string> actorsInMovie1 = imdb.find_actors_in_a_movie(matchedMovie1);
            set<string> actorsInMovie2 = imdb.find_actors_in_a_movie(matchedMovie2);

            cout << "Actors only in one of the two movies:" << endl;
            for (const auto& actor : actorsInMovie1) {
                if (!actorsInMovie2.count(actor)) {
                    cout << actor << endl;
                }
            }
            for (const auto& actor : actorsInMovie2) {
                if (!actorsInMovie1.count(actor)) {
                    cout << actor << endl;
                }
            }

        } else if (subOption == "Q" || subOption == "q") {
            break;  // Exit the submenu
        } else {
            cout << "Invalid Option!" << endl;
        }
    }
}
/*

 * Purpose: this function asks the user to type an actor's name and searches for co-actors in the movies they were in
 * @param imdb, the object of IMDB class: stores all information to look up
 */
void analyzeCoActors(const IMDB& imdb)
{
    string actor_name;
    cout << "Finding the co-actors of the actor by typing his/her name: ";
    getline(cin, actor_name);

    if (!imdb.isExistingActor(actor_name))
    {
        cout << "The actor name you entered is not in the database." << endl;
        return;
    }

    set<string> movies_of_actor = imdb.find_movies_for_an_actor(actor_name);
    for (const string& movie : movies_of_actor)
    {
        cout << "The co-actors of " << actor_name << " in the movie \"" << movie << "\" are: " << endl;
        set<string> coactors = imdb.find_actors_in_a_movie(movie);

        for (const string& coactor : coactors)
        {
            if (coactor != actor_name)  // Exclude the actor themselves
            {
                cout << coactor << endl;
            }
        }
        cout << "***********************************" << endl;
    }
}

