/*
 * Course: CS216-00x
 * Project: Project 2
 * Purpose: repeatedly ask the user to type prefix to match
 *          and generate all the prefix-matched terms 
 *          then display the prefix-matched terms in descending order by weight.
 ***** PLEASE DO NOT CHANGE THIS FILE *****
 */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <ctime>
#include "term.h"
#include "SortingList.h"
#include "autocomplete.h"
#include "powerString.h"

using namespace std;

int main(int argc, char** argv) {
    const int ARGUMENTS = 1;

    // Check the command line argument, an input file name is needed
    if (argc != ARGUMENTS + 2) {
        cout << "Usage: " << argv[0] << " <filename>" << endl; // Checks correct inputs
        return 1;
    }

    int size;
    int* temp = &size; // Changes char into integer using a pointer
    sscanf(argv[2], "%d", temp);

    if (size < 0) {
        cout << "Warning: the number of matching terms needs to be a positive number!" << endl; // Checks negative
        return 1;
    }

    // Check if the input file can be opened successfully
    ifstream infile;
    infile.open(argv[1]);
    if (!infile.good()) {
        cout << "Cannot open the file named " << argv[1] << endl;
        return 2;
    }

    // Read in the terms from the input file line by line and store into Autocomplete object
    Autocomplete autocomplete;
    long weight;
    string query;

    while (!infile.eof()) {
        infile >> weight >> ws;
        getline(infile, query);
        if (query != "") {
            Term newterm(query, weight);
            autocomplete.insert(newterm);
        }
    }

    // Measure the time spent for sorting operation
    clock_t tstart, tstop;
    tstart = clock();
    autocomplete.sort();
    tstop = clock();
    double elapsed = (double)(tstop - tstart) / CLOCKS_PER_SEC;
    cout << "Time for sorting all terms: " << elapsed << " seconds." << endl;

    // Begin user interaction
    string input;
    cout << "Please input the search query (type \"exit\" to quit): " << endl;
    getline(cin, input);

    while (input != "exit") { // Check raw input before normalization
        // Normalize the input
        powerString normalizedInput(input);
        normalizedInput.removeExtraSpace(); // Remove extra spaces
        string prefix = normalizedInput.wordFormat(); // Capitalize first letter of each word

        // Measure the time spent for searching one prefix-matched term
        tstart = clock();
        SortingList<Term> matchedTerms = autocomplete.allMatches(prefix);
        tstop = clock();
        elapsed = (double)(tstop - tstart) / CLOCKS_PER_SEC;
        cout << "Time for searching the maximum three of matched terms: " << elapsed << " seconds." << endl;

        if (matchedTerms.size() == 0) {
            cout << "No matched query!" << endl;
        } else {
            if (size > matchedTerms.size()) {
                for (size_t i = 0; i < matchedTerms.size(); i++) {
                    cout << matchedTerms[i] << endl;
                }
            } else {
                for (size_t i = 0; i < size; i++) {
                    cout << matchedTerms[i] << endl;
                }
            }
        }

        cout << "Enjoy CS216 Auto-complete Me search engine!" << endl
             << "It is written by Lucas Morris in CS216 section 004" << endl;

        // Prompt for next input
        cout << "Please input the search query (type \"exit\" to quit): " << endl;
        getline(cin, input); // Get next user input
    }

    
    return 0;
}
